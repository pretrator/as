const {
    beginTransaction,
    executeQueryAsync,
    commitTransaction,
  } = require("./database/postgres");

const config = require('./settings');
const parser = require('cron-parser');
const axios = require('axios');

const updateLogs = async (jobDetails, nextExecutionEpoch) => {
    try {
        const { data, msg, status, startTime, req, res } = jobDetails;
        const { job_id } = data;
        const endTime = (new Date()).getTime().toString();
        const params = [job_id, msg, startTime, status, endTime, nextExecutionEpoch, req, res];
        const client = await beginTransaction();
        const insertedLog = await executeQueryAsync(
          "INSERT INTO joblogs (schedulerjob_id, text, job_start_time, status, job_end_time, next_execution_epoch, req, res) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *;",
          params,
          client
        );
        const { schedulerjob_id, id } = insertedLog.rows[0]
        await executeQueryAsync(
          "UPDATE jobs SET last_log_id = $1 WHERE id = $2",
          [id, schedulerjob_id],
          client
        );
        await commitTransaction(client);
      } catch (err) {
        console.log(err)
      }
};

const delayAlert = async (startTime, jobId) => {
  const lastLogIdQuery = `SELECT last_log_id from jobs where id = $1;`;
  const logIdData = await executeQueryAsync(lastLogIdQuery, [jobId]);
  if(logIdData.rows.length === 0){
    return
  }
  const lastLogQuery = `SELECT next_execution_epoch from joblogs where id = $1;`;
  const logData = await executeQueryAsync(lastLogQuery, [logIdData.rows[0].last_log_id]);
  if(logData.rows.length){
    const nextExecutionEpoch = logData.rows[0].next_execution_epoch;
    const delay = Date.parse(startTime) - nextExecutionEpoch;
    if(delay > 60000){
      errorMssg = '``` Service: Cron Service \n Error: Job Delay \n Job Id: '+ jobId + ' \n delayMills: ' + delay + ' \n startTime: ' + startTime + '```';
      sendSlackAlert(errorMssg);
    }
  }
}

const sendSlackAlert = async (errorMssg) => {
  try {
    const data = JSON.stringify({
      "text": errorMssg
    });
    const URL = config.SLACK_URL;
    const reqConfig = {
      method: 'post',
      url: URL,
      headers: { 
        'Content-type': 'application/json'
      },
      data : data
    };
    await axios(reqConfig)
  } catch (err) {
    console.log(err)
  }
}

const arrayToObject = (arr) => {
  const obj = {}
  arr.forEach((keyValPair) => {
    if(keyValPair.key){
      obj[keyValPair.key] = keyValPair.value;
    }
  })
  return obj;
}

const getNextExecutionEpoch = (startTime, cron) => {
  const options = {
    currentDate: new Date(startTime),
  };
  const interval = parser.parseExpression(cron, options);
  const nextExecutionEpoch = Date.parse(interval.next());
  return {
    nextExecutionEpoch
  }
}

module.exports = {
    updateLogs,
    arrayToObject,
    getNextExecutionEpoch,
    delayAlert
};