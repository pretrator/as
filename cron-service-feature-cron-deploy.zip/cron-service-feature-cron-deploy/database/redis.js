const { REDIS_CONFIG, REDIS_CONNECT_TIMEOUT } = require('../settings');
const Redis = require('ioredis');

exports.getRedisClient = async () => {
	let redis;
	const { NODES, IS_REDIS_TLS, REDIS_PASSWORD, REDIS_SERVER, IS_REDIS_CLUSTER, RETRY_DELAY_ON_MOVED } = REDIS_CONFIG;
	const opts = { redisOptions: { 
		maxRetriesPerRequest : null,
		connectTimeout: REDIS_CONNECT_TIMEOUT,
		enableReadyCheck: false, 
		retryDelayOnMoved: RETRY_DELAY_ON_MOVED }};
	if(IS_REDIS_CLUSTER){
		if(IS_REDIS_TLS){
			opts.redisOptions.tls = {
				checkServerIdentity: (servername, cert) => {
					// skip certificate hostname validation
					return undefined;
				}
			};
		}
		if (REDIS_PASSWORD) {
			opts.redisOptions.password = REDIS_PASSWORD;
		}
		redis = await new Redis.Cluster(NODES, opts);
	}else{
		redis = await new Redis(REDIS_SERVER, opts);
	}
	return redis;
}