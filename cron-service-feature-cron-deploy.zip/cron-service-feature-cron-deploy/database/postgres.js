const { Pool } = require('pg');
const config = require('../settings');

let pool;

const connectPostgres = async () => {
    pool = await new Pool({
        ...config.POSTGRES,
    });
    console.log("Connected to Postgres Successfuly");
}

const rollbackTransaction = async (client, options) => {
    try{
        await client.query(`ROLLBACK;`);
    }
    catch(e){
        throw e;
    }
    finally{
        client.release();
    }
}

const commitTransaction = async (client, options) => {
    try{
        await client.query(`COMMIT;`);
        client.release();
    }
    catch(e){
        await rollbackTransaction(client);
        throw e;
    }
}

const beginTransaction = async (options) => {
    try{
        const client = await pool.connect();
        await client.query(`BEGIN;`);
        return client;
    }
    catch(e){
        throw e;
    }
}

const executeQueryAsync = async (query, parameters, client, options) => {
    try {
        if(client){
            const result = await client.query(query, parameters);
            return result
        }
        else{
            const result = await pool.query(query, parameters);
            return result
        }
    } catch (err) {
        if(client){
            await rollbackTransaction(client, options);
        }
        throw err;
    }
};

module.exports = {
    connectPostgres,
    rollbackTransaction,
    commitTransaction,
    beginTransaction,
    executeQueryAsync,
    pool,
}