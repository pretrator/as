const config = require('./config.json');
const lodash = require('lodash');
const defaultSettings = {
    START_SHARD_ID: 100,
    END_SHARD_ID: 102,
    RUN_SCHEDULER: true,
    SERVER_PORT: 8000,
    REDIS_CONNECT_TIMEOUT: 10000,
    WORKER_LEVEL_CONCURRENCY: 50,
    JWT_SECRET: '41271fbb91fbsatvvk',
    JOB_TIMEOUT: 120000, // 2 mins
    AUTHENTICATE_BASEURL: 'http://testonlinebooking.shipsy.in:5005',
    REDIS_CONFIG: {
        IS_REDIS_CLUSTER: false,
        IS_REDIS_TLS: false,
        REDIS_SERVER: 'redis://127.0.0.1:6379',
        RETRY_DELAY_ON_MOVED: 200,
    }
};
module.exports = lodash.assign(defaultSettings, config);
