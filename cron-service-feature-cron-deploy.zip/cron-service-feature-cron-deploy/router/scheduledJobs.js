const express = require("express");
const cronValidator = require("cron-validator");
const router = express.Router();
const jwt = require("jsonwebtoken");
const {
  beginTransaction,
  executeQueryAsync,
  commitTransaction,
  pool,
} = require("./../database/postgres");
const lodash = require("lodash");
const { START_SHARD_ID, END_SHARD_ID } = require("./../settings");
const { queueHash } = require("./../queue");
const config = require("../settings");

router.post("/create", async (req, res, next) => {
  const { body } = req;
  const client = await beginTransaction();
  const { name, cron, job_data, job_path, isJob = true, ancestorFolderId } = body;
  const shard = lodash.random(START_SHARD_ID, END_SHARD_ID - 1);
  const queue = queueHash[shard].queue;
  const params = [shard, name, cron, job_data, job_path, ancestorFolderId];
  if (!name) {
    return next({ error: { message: "Please Enter Valid Name" } });
  } else if (isJob) {
    if (!cronValidator.isValidCron(cron)) {
      return next({ error: { message: "Please Enter Valid Cron" } });
    } else if (!job_data.url) {
      return next({ error: { message: "Please Enter URL" } });
    }
  }
  let pathElement = job_path.split("/");
  if(job_path === ''){
    pathElement = [];
  }
  let createdJob;

  if (isJob) {
    createdJob = await executeQueryAsync(
      "INSERT INTO jobs (shard, name, cron, job_data, job_path, ancestor_folder_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *;",
      params,
      client
    );
  } else {
    pathElement.concat(name).forEach(async (folderName, index) => {
      const filter = [index, folderName];
      const data = await executeQueryAsync(
        `SELECT * FROM jobshierarchy WHERE level = $1 AND folder_name = $2 LIMIT 1;`,
        filter
      );
      if (data.rows.length === 0) {
        const newFolder = [
          index,
          folderName,
          index === 0 ? null : pathElement[index - 1],
          ancestorFolderId
        ];
        await executeQueryAsync(
          `INSERT INTO jobshierarchy (level, folder_name, ancestor_folder_name, ancestor_folder_id) VALUES ($1, $2, $3, $4);`,
          newFolder
        );
      }
    });
  }
  await commitTransaction(client);
  if (isJob) {
    await queue.add(
      name,
      {
        name,
        cron,
        job_data,
        shard,
        job_url: job_data.url,
        job_id: createdJob.rows[0].id,
      },
      { repeat: { cron }, jobId: createdJob.rows[0].id }
    );
  }
  res.status(200).json({ msg: "Job/Folder Addition Succeeded " });
});


router.get("/details", async (req, res) => {
  const { query } = req;
  const { jobId } = query;
  const getDetailQuery = `SELECT id, is_active, name, cron, job_data, job_path, created_at from jobs where id = $1 LIMIT 1;`;
  const data = await executeQueryAsync(getDetailQuery, [jobId]);
  res.status(200).json(data.rows);
});

router.post("/deleteFolder", async (req, res) => {
  const { body } = req;
  const { path, folderId } = body;
  const client = await beginTransaction();
  let folderChildList = [folderId];
  while(folderChildList.length){
    // REMOVE FOLDERS
    await executeQueryAsync(
        `DELETE FROM jobshierarchy where id IN (${folderChildList.toString()});`,
        [],
        client
      );
    // REMOVE JOBS
    const queryString = `SELECT * FROM jobs WHERE ancestor_folder_id IN (${folderChildList.toString()});`;
    const jobsList = await executeQueryAsync(queryString)
    jobsList.rows.forEach( async(jobDetails) => {
      const { name, cron, job_data, shard, id } = jobDetails;
      const queue = queueHash[shard].queue;
      // GETTING A JOB
      const job = await queue.add(
        name,
        {
          name,
          cron,
          job_data,
          shard,
          job_url: job_data.url,
          job_id: id,
        },
        { repeat: { cron }, jobId: id }
      );   
      // REMOVING A JOB
      await job.remove();
    })
    if(jobsList.rows.length){
      await executeQueryAsync(
        `DELETE FROM jobs where id in (${jobsList.rows.map((row) => row.id).toString()});`,
        [],
        client
      );
    }
    newFolderChildList = await executeQueryAsync(
      `SELECT id from jobshierarchy where ancestor_folder_id IN (${folderChildList.toString()});`)
      .then((data) => data.rows.map((row) => row.id));
    folderChildList = newFolderChildList;
  }
  await commitTransaction(client);
  res.status(200).json({
    msg: "Deleted Successfully",
  });
});

router.get("/getJobs", async (req, res) => {
  const { query } = req;
  const { ancestorFolderId, searchText } = query;
  const ancestorClause = ancestorFolderId ? ` = ${ancestorFolderId}` : 'IS NULL' 
  const likeClause = (nameKey) => searchText ? `AND ${nameKey} LIKE '${searchText}%'`: ''
  queryString = `
    SELECT id, name, is_active, 'job' as "type", ancestor_folder_id, updated_at FROM jobs
    WHERE ancestor_folder_id ${ancestorClause}
    ${likeClause('name')}
    UNION
    SELECT id, folder_name as "name", true as "is_active", 'folder' as "type", ancestor_folder_id, updated_at FROM jobshierarchy
    WHERE ancestor_folder_id ${ancestorClause}
    ${likeClause('folder_name')}
    ORDER BY updated_at DESC;`
  data = await executeQueryAsync(queryString);
  res.json(data.rows);
});

router.post(`/deleteJob`, async (req, res) => {
  const { body } = req;
  const { jobId } = body;
  const queryString = `SELECT * FROM jobs WHERE id=${jobId}`;
  const data = await executeQueryAsync(queryString);
  const { shard, name, job_data, cron, id } = data.rows[0];
  const queue = queueHash[shard].queue;

  const job = await queue.add(
    name,
    { name, cron, job_data, shard, job_url: job_data.url, job_id: id },
    { repeat: { cron }, jobId: id }
  );

  const client = await beginTransaction();
  await executeQueryAsync(`DELETE FROM jobs WHERE id = $1;`, [jobId], client);
  await commitTransaction(client);
  await job.remove();
  res.status(200).json({
    msg: "Delete Successfull",
  })
});

router.post("/updateJob", async (req, res, next) => {
  const { body } = req;
  const updatableFields = ["is_active", "name", "cron", "job_data"];
  const client = await beginTransaction();
  const { update, jobId } = body;
  let { cron, name, job_data, is_active } = update;

  if (!name && !cron && !job_data) {
    // Pass
  } else if (!name) {
    return next({ error: { message: "Please Enter Valid Name" } });
  } else if (!cronValidator.isValidCron(cron)) {
    return next({ error: { message: "Please Enter Valid Cron" } });
  } else if (!job_data.url) {
    return next({ error: { message: "Please Enter URL" } });
  }

  // GET JOB DETAILS FROM DB
  const queryString = `SELECT * FROM jobs WHERE id=${jobId}`;
  const currentJob = await executeQueryAsync(queryString);
  const {
    shard,
    name: currentJobName,
    job_data: currentJobData,
    cron: currentCron,
  } = currentJob.rows[0];
  const queue = queueHash[shard].queue;

  const fieldsToUpdate = lodash
    .keys(update)
    .filter((key) => updatableFields.includes(key));
  const updateText = fieldsToUpdate
    .map((key, index) => `${key} = $${index + 1}`)
    .join(" , ");
  const updateArr = fieldsToUpdate.map((key) => update[key]);
  const data = await executeQueryAsync(
    `UPDATE jobs SET ${updateText} WHERE id = ${jobId};`,
    updateArr,
    client
  );
  await commitTransaction(client);

  // getting job
  const job = await queue.add(
    currentJobName,
    {
      name: currentJobName,
      cron: currentCron,
      job_data: currentJobData,
      shard,
      job_url: currentJobData.url,
      job_id: jobId,
    },
    { repeat: { cron: currentCron }, jobId: jobId }
  );

  // removing job
  await job.remove();

  name = name ? name : currentJobName;
  cron = cron ? cron : currentCron; 
  job_data = job_data ? job_data : currentJobData;

  if (is_active) {
    await queue.add(
      name,
      { name, cron, job_data, shard, job_url: job_data.url, job_id: jobId },
      { repeat: { cron }, jobId: jobId }
    );
  }

  res.status(200).json({
    msg: "Update Successfull",
  });
});

router.get(`/test`, async (req, res) => {
  res.status(200).json({
    msg: "Test Successfull",
  });
});

router.post(`/logs`, async (req, res, next) => {
  const { body, headers } = req;
  const { logtoken: token } = headers;
  const { currentStatus, message, jobStartTime, jobEndTime } = body;
  const validStatus = ["completed", "failed", "processing"];
  try {
    const { data: decoded } = jwt.verify(token, config.JWT_SECRET);
    const { job_id } = decoded;
    const params = [job_id, message, jobStartTime, jobEndTime, currentStatus];
    if (!validStatus.includes(currentStatus)) {
      return next({ error: { message: "Invalid Status" } });
    }
    const client = await beginTransaction();
    insertedLog = await executeQueryAsync(
      "INSERT INTO joblogs (schedulerjob_id, message, job_start_time, job_end_time, status) VALUES ($1, $2, $3, $4, $5) RETURNING *;",
      params,
      client
    );
    await commitTransaction(client);
  } catch (err) {
    return next({ error: { message: "Bad Token" } });
  }
  res.status(200).json({
    msg: "Logs Added",
  });
});

router.get(`/logs`, async (req, res) => {
  const { query } = req;
  const { jobId } = query;
  let queryString = `SELECT * FROM joblogs WHERE schedulerjob_id = ${jobId} ORDER BY created_at DESC limit 500`;
  data = await executeQueryAsync(queryString);
  res.status(200).json(data.rows);
});

module.exports = router;
