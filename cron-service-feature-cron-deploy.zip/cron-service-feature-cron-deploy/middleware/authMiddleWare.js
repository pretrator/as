const axios = require('axios');
const config = require('../config.json');
var base64 = require('base-64');

const authenticateMiddleware = (req, res, next) =>  {
    const sendUnauthorised = (resp) => {
        resp.status(401).json({
            statusCode: 401,
            message: 'User is unauthenticated!',
            error: 'Unauthenticated',
        });
    };
    try{
        const tokenArr = req.headers.authorization.split("Basic ")
        const authString = base64.decode(tokenArr[1]);
        const authArr = authString.split(':');
        return axios
        .get(`${config.AUTHENTICATE_BASEURL}/authenticate`, {
            auth: {
                username: authArr[0],
                password: authArr[1],
            },
        })
        .then(
            (authResp) => {
                if (authResp && authResp.data && authResp.data.status === 'OK') {
                    req.user = authResp.data.data;
                    next();
                } else {
                    sendUnauthorised(res);
                }
            },
            (err) => {
                sendUnauthorised(res);
            },
        );
    }catch(e){
        return sendUnauthorised(res);
    }
}
module.exports = {
    authenticateMiddleware
};