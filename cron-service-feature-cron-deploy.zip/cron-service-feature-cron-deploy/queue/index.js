const config = require('../settings');
const lodash = require('lodash');
const Redis = require('ioredis');
const { Queue, Worker, QueueScheduler } = require('bullmq');
const axios = require('axios');
const { RUN_SCHEDULER, JOB_TIMEOUT } = require('./../settings');
const jwt = require('jsonwebtoken');
const { updateLogs, arrayToObject, getNextExecutionEpoch, delayAlert } = require('../common');
const { getRedisClient } = require('./../database/redis');

const jobHandler = async (job) => {
    const payload = { job_id: job.data.job_id }
    const token = jwt.sign({data: payload}, config.JWT_SECRET);
    job.data.job_data.req = {...job.data.job_data}
    job.data.job_data.req.headers = { ...arrayToObject(job.data.job_data.headers), logToken: token }
    job.data.job_data.req.params = arrayToObject(job.data.job_data.params)
    job.data.job_data.req.body = job.data.job_data.body ? JSON.parse(job.data.job_data.body) : {}; 
    const startTime = (new Date()).getTime().toString();
    const res = await axios({...job.data.job_data.req, timeout: JOB_TIMEOUT}).catch((e) => {
        throw new Error(JSON.stringify({msg: e.message, startTime, req: job.data.job_data.req }));
    })
    return {
        data: res.data, 
        startTime, 
        req: job.data.job_data.req,
        status: {
            code: res.status,
            statusText: res.statusText,
        },
        res: {
            headers: res.headers,
            params: res.params,
            body: res.body,
        }
    };
}

const queueHash = {};

exports.initialiseWorkerAndQueue = async () => {
    const allShards = lodash.range(config.START_SHARD_ID, config.END_SHARD_ID);
    const redis = await getRedisClient();
    allShards.forEach((id) => {
        queueHash[`${id}`] = {};
        queueHash[`${id}`].queue =  new Queue(`cron-server-${id}`, {
            prefix: `{${id}}`,
            defaultJobOptions: {
				removeOnComplete: true,
				removeOnFail: true,
			},
            connection: redis });
        queueHash[`${id}`].worker = new Worker(`cron-server-${id}`, jobHandler, { 
            concurrency: config.WORKER_LEVEL_CONCURRENCY, connection: redis,
            prefix: `{${id}}`,
        });
        queueHash[`${id}`].worker.on('completed', (job, returnvalue) => {
            const { startTime, data, req, res, status } = returnvalue;
            const { data: jobData, opts } = job;
            delayAlert(startTime, jobData.job_id);
            const { nextExecutionEpoch } = getNextExecutionEpoch(opts.prevMillis, jobData.cron);
            const updateLogData = { ...job, req, res, msg: JSON.stringify(data), startTime, status: status};
            updateLogs(updateLogData, nextExecutionEpoch);
        });
        queueHash[`${id}`].worker.on('failed', (job, error) => {
            const { msg, startTime, req } = JSON.parse(error.message);
            const { data, opts } = job;
            delayAlert(startTime, data.job_id);
            const { nextExecutionEpoch } = getNextExecutionEpoch(opts.prevMillis, data.cron);
            const updateLogData = { ...job, req, status, msg, startTime };
            updateLogs(updateLogData, nextExecutionEpoch);
        });
    });
    console.log("All Queue/Worker pair initialised");
};

exports.initialiseQueueScheduler = async () => {
    if(RUN_SCHEDULER){
        const allShards = lodash.range(config.START_SHARD_ID, config.END_SHARD_ID);
        allShards.forEach(async (id) => {
            const redis = await getRedisClient();
            queueHash[`${id}`].schedular =  new QueueScheduler(`cron-server-${id}`, { 
                connection: redis, 
                prefix: `{${id}}`,
            });
        });
        console.log("All Scheduler Initialised");
    }
}

exports.queueHash = queueHash;
