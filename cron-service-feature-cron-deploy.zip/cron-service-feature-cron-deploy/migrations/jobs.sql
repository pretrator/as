CREATE TABLE jobs (
    id bigserial PRIMARY KEY,
	organisation_id text,
    shard text,
    is_active boolean DEFAULT true,
    name text NOT NULL,
    cron text NOT NULL,
    job_data jsonb,
	job_path text,
    created_at timestamp with time zone default CURRENT_TIMESTAMP,
    updated_at timestamp with time zone default CURRENT_TIMESTAMP
);

CREATE TABLE jobshierarchy (
	id bigserial PRIMARY KEY, 
	organisation_id text,
	folder_name text,
    ancestor_folder_name text,
	type text, -- job/folder
    schedulerjob_id bigint,
    level integer,
    created_at timestamp with time zone default CURRENT_TIMESTAMP,
    updated_at timestamp with time zone default CURRENT_TIMESTAMP
);

CREATE TABLE joblogs (
    id bigserial PRIMARY KEY, 
	schedulerjob_id bigint,
	text text,
	status jsonb,
	job_start_time varchar(128),
	job_end_time varchar(128),
	created_at timestamp with time zone default CURRENT_TIMESTAMP,
    next_execution_epoch bigint,
    req jsonb,
    res jsonb
);

ALTER TABLE jobshierarchy DROP column organisation_id;
ALTER TABLE jobs DROP column organisation_id;

ALTER TABLE jobshierarchy ADD column ancestor_folder_id bigint;
ALTER TABLE jobs ADD column ancestor_folder_id bigint;

ALTER TABLE jobshierarchy DROP column schedulerjob_id;
ALTER TABLE jobshierarchy DROP column type;

ALTER TABLE jobs ADD column last_log_id bigint;
