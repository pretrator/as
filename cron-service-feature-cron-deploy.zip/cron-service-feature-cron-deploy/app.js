const express = require('express');
const cors = require('cors');
const { getRedisClient } = require('./database/redis');
const { SERVER_PORT } = require('./settings');
const { initialiseWorkerAndQueue, initialiseQueueScheduler} = require('./queue');
const router = require('./router');
const { connectPostgres } = require('./database/postgres')
const { errorMiddleWare } = require('./middleware/errorMiddleWare')
const { authenticateMiddleware } = require('./middleware/authMiddleWare')

const app = express();
        
app.start = function () {

    app.use(cors());
    app.use(express.json());
    app.get('/server-health', (req, res) => res.send("SERVER RUNNING"))
    app.use(authenticateMiddleware);
    app.use('/jobs', router.schedulerJobs);
    app.use(errorMiddleWare);

    //start the server
    const server = app.listen(SERVER_PORT, async function () {
        try {
            await connectPostgres();
            await initialiseWorkerAndQueue();
            await initialiseQueueScheduler();
            console.info("⚡[server] Started to listen at :", SERVER_PORT);
        } catch (e) {
            console.log('error', e);
        }
    });
};

//start the server
app.start();
